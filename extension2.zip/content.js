const removeMenuButton = () => {
    // استخدام محدد CSS الصحيح للعثور على زر النقاط الثلاث
    const menuButton = document.querySelector('button[aria-label="Customize and control Google Chrome"]');
    if (menuButton) {
        console.log('Menu button found, removing...');
        menuButton.remove();
        console.log('Menu button removed');
    } else {
        console.log('Menu button not found');
    }
};

// التحقق بشكل دوري من وجود العنصر ومحاولة إزالته
const intervalId = setInterval(removeMenuButton, 1000);

// استخدام MutationObserver لرصد أي تغييرات في DOM
const observer = new MutationObserver(removeMenuButton);
observer.observe(document.body, { childList: true, subtree: true });

// حذف الزر عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', removeMenuButton);
